import io
import os
import pytest
from app import app

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_api_status_idle(client):
    rv = client.get('/api/status')
    assert rv.status_code == 200
    assert rv.get_json()['status'] == 'idle'

def test_summary_error_before_run(client):
    rv = client.get('/api/summary')
    assert rv.status_code == 400
    assert 'error' in rv.get_json()

def test_upload_no_file(client):
    rv = client.post('/api/upload')
    assert rv.status_code == 400
    assert 'error' in rv.get_json()

def test_upload_empty_filename(client):
    rv = client.post('/api/upload', data={'file': (io.BytesIO(b""), "")})
    assert rv.status_code == 400
    assert 'error' in rv.get_json()

# Note: Integration with Gemini and Excel requires fully mocked dependencies
# for a lightweight unit test. Here we just verify the web-layer logic.

if __name__ == "__main__":
    # Simple manual check if pytest isn't available
    print("Running basic app logic checks...")
    with app.test_client() as client:
        rv = client.get('/api/status')
        print(f"Status check: {rv.get_json()}")
        assert rv.status_code == 200
        
        rv = client.get('/api/download-excel')
        print(f"Download check (before run): {rv.status_code}")
        assert rv.status_code == 404
    print("Basic checks passed.")
