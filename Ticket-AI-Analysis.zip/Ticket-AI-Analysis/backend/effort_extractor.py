import pandas as pd
import re
from datetime import datetime, timedelta

class EffortExtractor:
    """
    Parses the 'Comments Work notes' column.
    Each entry contains timestamped notes in formats like:
      2024-01-15 09:30:00 - Assigned to team
      2024-01-15 11:45:00 - Issue resolved
    Calculates time between first and last timestamp as effort proxy.
    """

    TIMESTAMP_PATTERNS = [
        r'\b(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})\b',       # 2024-01-15 09:30:00
        r'\b(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2})\b',       # 01/15/2024 09:30:00
        r'\b(\d{2}/\d{2}/\d{4}\s+\d{1,2}:\d{2}:\d{2}\s*[AaPp][Mm])\b', # 01/15/2024 09:30:00 AM
        r'\b(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\b',         # 2024-01-15T09:30:00
        r'\b(\d{2}-\d{2}-\d{4}\s+\d{2}:\d{2})\b',             # 15-01-2024 09:30
        r'\b(\d{1,2}\s+\w{3,9}\s+\d{4}\s+\d{2}:\d{2}:\d{2})\b', # 15 January 2024 09:30:00
        r'\b(\w{3,9}\s+\d{1,2},\s+\d{4}\s+\d{2}:\d{2}:\d{2})\b', # Jan 15, 2024 09:30:00
        r'\b(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})\b',             # 2024-01-15 09:30
    ]

    DATE_FORMATS = [
        '%Y-%m-%d %H:%M:%S',
        '%m/%d/%Y %H:%M:%S',
        '%m/%d/%Y %I:%M:%S %p',
        '%Y-%m-%dT%H:%M:%S',
        '%d-%m-%Y %H:%M',
        '%d %B %Y %H:%M:%S',
        '%b %d, %Y %H:%M:%S',
        '%Y-%m-%d %H:%M',
    ]

    def extract_effort(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()

        df['First_Timestamp'] = None
        df['Last_Timestamp'] = None
        df['Effort_Hours'] = None
        df['Effort_Minutes'] = None
        df['Note_Count'] = 0

        worknotes_col = self._find_worknotes_column(df)
        if worknotes_col is None:
            print("Warning: No work notes column found. Effort will be null.")
            return df

        print(f"Extracting effort from column: '{worknotes_col}'")

        for idx, row in df.iterrows():
            raw_notes = str(row.get(worknotes_col, ''))
            if not raw_notes or raw_notes == 'nan' or raw_notes.strip() == '':
                continue

            timestamps = self._extract_timestamps(raw_notes)
            note_count = self._count_notes(raw_notes)

            df.at[idx, 'Note_Count'] = note_count

            if len(timestamps) >= 2:
                timestamps.sort()
                first_ts = timestamps[0]
                last_ts = timestamps[-1]
                delta = last_ts - first_ts
                hours = delta.total_seconds() / 3600

                df.at[idx, 'First_Timestamp'] = first_ts
                df.at[idx, 'Last_Timestamp'] = last_ts
                df.at[idx, 'Effort_Hours'] = round(hours, 2)
                df.at[idx, 'Effort_Minutes'] = round(delta.total_seconds() / 60, 1)

            elif len(timestamps) == 1:
                # Single timestamp or single entry: estimate 30 min base effort
                df.at[idx, 'First_Timestamp'] = timestamps[0]
                df.at[idx, 'Last_Timestamp'] = timestamps[0]
                df.at[idx, 'Effort_Hours'] = 0.5
                df.at[idx, 'Effort_Minutes'] = 30.0

        return df

    def _find_worknotes_column(self, df: pd.DataFrame) -> str:
        """Find the work notes column regardless of exact casing/naming"""
        # Exact match candidates
        candidates = [
            'Comments Work notes',
            'Comments and Work Notes',
            'Work Notes',
            'WorkNotes',
            'Comments',
            'Work notes',
            'Resolution Notes'
        ]
        
        # 1. Try exact matches first
        for col in candidates:
            if col in df.columns:
                return col
        
        # 2. Case-insensitive lookup
        lower_candidates = [c.lower() for c in candidates]
        for col in df.columns:
            if col.lower() in lower_candidates:
                return col
        
        # 3. Fuzzy fallback (contains 'note' or 'comment')
        for col in df.columns:
            lcol = col.lower()
            if 'note' in lcol or 'comment' in lcol:
                return col
        return None

    def _extract_timestamps(self, text: str) -> list:
        """Extract all timestamps from a work notes string, resolving overlaps"""
        matches = self._find_best_matches(text)
        found = []
        for m in matches:
            try:
                # Normalize whitespace for parsing
                clean_match = ' '.join(m['text'].strip().split())
                fmt = m['fmt']
                ts = datetime.strptime(clean_match, fmt)
                found.append(ts)
            except ValueError:
                # Try abbreviated month if full name fails and vice versa
                try:
                    if '%B' in fmt:
                        ts = datetime.strptime(clean_match, fmt.replace('%B', '%b'))
                        found.append(ts)
                    elif '%b' in fmt:
                        ts = datetime.strptime(clean_match, fmt.replace('%b', '%B'))
                        found.append(ts)
                except ValueError:
                    continue
        return list(set(found))

    def _count_notes(self, text: str) -> int:
        """Count individual note entries by counting unique non-overlapping timestamp occurrences"""
        matches = self._find_best_matches(text)
        count = len(matches)
        return count if count > 0 else (1 if text.strip() else 0)

    def _find_best_matches(self, text: str) -> list:
        """Helper to find all timestamp matches and resolve overlaps (prefer longer matches)"""
        all_matches = []
        for pattern, fmt in zip(self.TIMESTAMP_PATTERNS, self.DATE_FORMATS):
            for m in re.finditer(pattern, text, re.IGNORECASE):
                all_matches.append({
                    'text': m.group(1),
                    'start': m.start(1),
                    'end': m.end(1),
                    'fmt': fmt
                })
        
        if not all_matches:
            return []

        # Sort by start position, then by length (descending)
        all_matches.sort(key=lambda x: (x['start'], -(x['end'] - x['start'])))
        
        final_matches = []
        last_end = -1
        for m in all_matches:
            if m['start'] >= last_end:
                final_matches.append(m)
                last_end = m['end']
        
        return final_matches
