import google.generativeai as genai
import pandas as pd
import json
import time
import os
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

class GeminiCategorizer:
    def __init__(self):
        self.model = genai.GenerativeModel("gemini-1.5-flash")
        self.batch_size = 20  # Tickets per Gemini call to stay within token limits

    def categorize_tickets(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Main entry point. Applies categorization logic:
        - If Item != 'General Request': use Item + Subcategory1 + Subcategory2
        - If Item == 'General Request': use Gemini to infer category from
          Short Description + Business Service
        """
        df = df.copy()
        df['AI_Category'] = None
        df['AI_Subcategory'] = None
        df['AI_Group'] = None
        df['Category_Source'] = None

        # Split into structured vs unstructured rows
        structured_mask = (
            df['Item'].notna() &
            (df['Item'].str.strip().str.lower() != 'general request') &
            (df['Item'].str.strip() != '')
        )

        # --- Structured tickets: Item is meaningful ---
        df.loc[structured_mask, 'AI_Category'] = df.loc[structured_mask, 'Item'].str.strip()
        df.loc[structured_mask, 'AI_Subcategory'] = (
            df.loc[structured_mask, 'Subcategory 1'].fillna('').str.strip()
        )
        df.loc[structured_mask, 'AI_Group'] = df.loc[structured_mask].apply(
            lambda r: self._build_group_label(r), axis=1
        )
        df.loc[structured_mask, 'Category_Source'] = 'Item Field'

        # --- Unstructured tickets: send to Gemini ---
        unstructured = df[~structured_mask].copy()
        if not unstructured.empty:
            categorized = self._categorize_with_gemini(unstructured)
            for col in ['AI_Category', 'AI_Subcategory', 'AI_Group', 'Category_Source']:
                df.loc[~structured_mask, col] = categorized[col].values

        return df

    def _build_group_label(self, row) -> str:
        """Build a combined group label from Item + Subcategory 1 + Subcategory 2"""
        parts = [str(row.get('Item', '')).strip()]
        sub1 = str(row.get('Subcategory 1', '')).strip()
        sub2 = str(row.get('Subcategory 2', '')).strip()
        if sub1 and sub1.lower() not in ('nan', ''):
            parts.append(sub1)
        if sub2 and sub2.lower() not in ('nan', ''):
            parts.append(sub2)
        return ' > '.join(parts)

    def _categorize_with_gemini(self, df: pd.DataFrame) -> pd.DataFrame:
        """Send unstructured tickets to Gemini in batches for categorization"""
        results = []
        indices = df.index.tolist()

        batches = [
            indices[i:i + self.batch_size]
            for i in range(0, len(indices), self.batch_size)
        ]

        print(f"Sending {len(df)} General Request tickets to Gemini in {len(batches)} batches...")

        for batch_num, batch_indices in enumerate(batches):
            batch_df = df.loc[batch_indices]
            batch_results = self._process_batch(batch_df)
            results.extend(batch_results)
            print(f"  Batch {batch_num + 1}/{len(batches)} complete.")
            # Respect rate limits
            time.sleep(1)

        result_df = pd.DataFrame(results, index=df.index)
        return result_df

    def _process_batch(self, batch_df: pd.DataFrame) -> list:
        """Process a single batch through Gemini with retry logic"""
        tickets_payload = []
        for idx, row in batch_df.iterrows():
            tickets_payload.append({
                "id": str(idx),
                "short_description": str(row.get('Short Description', '')),
                "business_service": str(row.get('Business Service', '')),
                "category": str(row.get('Category', '')),
                "subcategory_1": str(row.get('Subcategory 1', '')),
                "subcategory_2": str(row.get('Subcategory 2', ''))
            })

        prompt = self._build_prompt(tickets_payload)
        
        max_retries = 3
        for attempt in range(max_retries):
            try:
                response = self.model.generate_content(prompt)
                if not response.text:
                    raise ValueError("Empty response from Gemini")
                
                parsed = self._parse_gemini_response(response.text, batch_df)
                return parsed
            except Exception as e:
                print(f"Gemini API attempt {attempt + 1} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    print(f"All {max_retries} attempts failed for batch.")

        # Fallback: mark as uncategorized if all retries fail
        return [
            {
                'AI_Category': 'Uncategorized',
                'AI_Subcategory': '',
                'AI_Group': 'Uncategorized',
                'Category_Source': 'Fallback (API Error)'
            }
            for _ in range(len(batch_df))
        ]

    def _build_prompt(self, tickets: list) -> str:
        return f"""
You are an IT Service Management analyst. Analyze the following service desk tickets and categorize each one.

Rules:
1. Group similar tickets into meaningful IT service categories (e.g. "DNS - Add/Update/Delete", "AWS Access", "AD Group Access", "Hardware Issue", "Email Problem", "Network Connectivity", "Access & Permissions", "System Performance", etc.)
2. Use the short_description as primary signal. Use business_service as supporting context.
3. Assign:
   - "category": broad IT domain (e.g. "Access Management", "Hardware", "Network", "Software")
   - "subcategory": specific issue type (e.g. "Password Reset", "Laptop Issue", "VPN", "Office 365")
   - "group": a clean, consistent bucket label combining both (e.g. "Access Management > Password Reset")
4. Be consistent — similar descriptions must get the same group label.
5. Return ONLY a valid pure JSON array of objects.
6. NO markdown code fences, NO preamble, NO explanation text. Just the JSON.

Tickets:
{json.dumps(tickets, indent=2)}

Return format (one object per ticket, same order):
[
  {{
    "id": "original_id",
    "category": "...",
    "subcategory": "...",
    "group": "..."
  }}
]
"""

    def _parse_gemini_response(self, response_text: str, batch_df: pd.DataFrame) -> list:
        """Parse Gemini response and map back to rows with robust extraction"""
        try:
            # More robust JSON extraction: find the first '[' and last ']'
            text = response_text.strip()
            
            # Remove markdown code fences if present
            if "```" in text:
                # Try to extract content between fences
                parts = text.split("```")
                for part in parts:
                    part = part.strip()
                    if part.startswith("json"):
                        part = part[4:].strip()
                    if part.startswith("[") and part.endswith("]"):
                        text = part
                        break
                    # If not perfectly formatted, just try to find the array within the part
                    start = part.find('[')
                    end = part.rfind(']')
                    if start != -1 and end != -1 and end > start:
                        text = part[start:end+1]
                        break

            # If no fences worked, or if fences weren't used, search for [ ] in the whole text
            if not (text.startswith("[") and text.endswith("]")):
                start = text.find('[')
                end = text.rfind(']')
                if start != -1 and end != -1 and end > start:
                    text = text[start:end+1]

            parsed = json.loads(text)
            if not isinstance(parsed, list):
                if isinstance(parsed, dict) and "tickets" in parsed:
                    parsed = parsed["tickets"]
                else:
                    raise ValueError("Parsed JSON is not a list")

            # Map results to a predictable list
            results_map = {str(item.get('id')): item for item in parsed if 'id' in item}
            
            results = []
            for idx, _ in batch_df.iterrows():
                item = results_map.get(str(idx), {})
                results.append({
                    'AI_Category': item.get('category', 'Uncategorized'),
                    'AI_Subcategory': item.get('subcategory', ''),
                    'AI_Group': item.get('group', 'Uncategorized'),
                    'Category_Source': 'Gemini AI'
                })

            # Safety padding/truncation to match batch_df exactly
            if len(results) != len(batch_df):
                print(f"Warning: Gemini returned {len(results)} items for {len(batch_df)} tickets. Adjusting...")
                
            return results[:len(batch_df)]

        except (json.JSONDecodeError, ValueError) as e:
            print(f"Parsing error: {e}\nRaw response snippet: {response_text[:200]}...")
            return [
                {
                    'AI_Category': 'Uncategorized',
                    'AI_Subcategory': '',
                    'AI_Group': 'Uncategorized',
                    'Category_Source': 'Fallback (Parse Error)'
                }
                for _ in range(len(batch_df))
            ]
