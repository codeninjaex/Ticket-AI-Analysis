import pandas as pd
import json
from unittest.mock import MagicMock
from gemini_categorizer import GeminiCategorizer

def test_robust_parsing():
    categorizer = GeminiCategorizer()
    
    # Mocking the model
    categorizer.model = MagicMock()
    
    # Test case 1: Clean JSON with markup
    mock_response = MagicMock()
    mock_response.text = '```json\n[{"id": "0", "category": "Access", "subcategory": "Mock", "group": "Access > Mock"}]\n```'
    categorizer.model.generate_content.return_value = mock_response
    
    df = pd.DataFrame([{
        "Short Description": "test", 
        "Business Service": "test", 
        "Item": "General Request",
        "Subcategory 1": "",
        "Subcategory 2": ""
    }])
    result = categorizer.categorize_tickets(df)
    
    assert result.iloc[0]['AI_Category'] == 'Access'
    assert result.iloc[0]['Category_Source'] == 'Gemini AI'
    print("Test 1 (Clean JSON with markup) passed.")

    # Test case 2: JSON with preamble
    mock_response.text = 'Here is the analysis:\n[{"id": "0", "category": "Hardware", "subcategory": "Laptop", "group": "Hardware > Laptop"}]\nHope this helps!'
    categorizer.model.generate_content.return_value = mock_response
    
    result = categorizer.categorize_tickets(df)
    assert result.iloc[0]['AI_Category'] == 'Hardware'
    print("Test 2 (JSON with preamble) passed.")

    # Test case 3: Malformed JSON (Fallback)
    mock_response.text = 'Not a JSON'
    categorizer.model.generate_content.return_value = mock_response
    
    result = categorizer.categorize_tickets(df)
    assert result.iloc[0]['AI_Category'] == 'Uncategorized'
    assert 'Fallback' in result.iloc[0]['Category_Source']
    print("Test 3 (Malformed JSON) passed.")

    # Test case 4: Item Field (Structured)
    df_structured = pd.DataFrame([{
        "Short Description": "test", 
        "Business Service": "test", 
        "Item": "Laptop Repair",
        "Subcategory 1": "Hardware"
    }])
    result = categorizer.categorize_tickets(df_structured)
    assert result.iloc[0]['AI_Category'] == 'Laptop Repair'
    assert result.iloc[0]['Category_Source'] == 'Item Field'
    print("Test 4 (Structured item) passed.")

if __name__ == "__main__":
    try:
        test_robust_parsing()
        print("\nAll tests passed successfully!")
    except Exception as e:
        print(f"\nTests failed: {e}")
        import traceback
        traceback.print_exc()
