import pandas as pd
import numpy as np

class TicketAnalyzer:
    def __init__(self, df: pd.DataFrame):
        self.df = df.copy()

    def get_heavy_hitters(self, top_n: int = 15) -> dict:
        if self.df.empty or 'AI_Group' not in self.df.columns:
            return {
                'heavy_hitters': [],
                'total_tickets': len(self.df),
                'coverage_pct': 0
            }

        group_counts = self.df['AI_Group'].value_counts().head(top_n)
        total = len(self.df)
        cumulative = 0
        result = []
        for group, count in group_counts.items():
            pct = round((count / total) * 100, 2)
            cumulative += pct
            result.append({
                'group': group,
                'count': int(count),
                'percentage': pct,
                'cumulative_percentage': round(cumulative, 2)
            })
        return {
            'heavy_hitters': result,
            'total_tickets': total,
            'coverage_pct': round(cumulative, 2)
        }

    def get_effort_summary(self) -> dict:
        if self.df.empty or 'Effort_Hours' not in self.df.columns:
            return {
                'effort_by_group': [],
                'overall': {
                    'total_hours': 0,
                    'avg_hours_per_ticket': 0,
                    'tickets_with_effort': 0,
                    'tickets_without_effort': len(self.df)
                }
            }

        effort_df = self.df[self.df['Effort_Hours'].notna()].copy()
        if effort_df.empty:
            return {
                'effort_by_group': [],
                'overall': {
                    'total_hours': 0,
                    'avg_hours_per_ticket': 0,
                    'tickets_with_effort': 0,
                    'tickets_without_effort': len(self.df)
                }
            }

        group_col = 'AI_Group' if 'AI_Group' in effort_df.columns else None
        if not group_col:
             return {
                'effort_by_group': [],
                'overall': {
                    'total_hours': round(float(effort_df['Effort_Hours'].sum()), 2),
                    'avg_hours_per_ticket': round(float(effort_df['Effort_Hours'].mean()), 2),
                    'tickets_with_effort': int(len(effort_df)),
                    'tickets_without_effort': int(len(self.df) - len(effort_df))
                }
            }

        by_group = effort_df.groupby(group_col).agg(
            ticket_count=('Effort_Hours', 'count'),
            total_hours=('Effort_Hours', 'sum'),
            avg_hours=('Effort_Hours', 'mean'),
            min_hours=('Effort_Hours', 'min'),
            max_hours=('Effort_Hours', 'max'),
        ).round(2).reset_index()

        by_group = by_group.sort_values('total_hours', ascending=False)

        return {
            'effort_by_group': by_group.to_dict('records'),
            'overall': {
                'total_hours': round(float(effort_df['Effort_Hours'].sum()), 2),
                'avg_hours_per_ticket': round(float(effort_df['Effort_Hours'].mean()), 2),
                'tickets_with_effort': int(len(effort_df)),
                'tickets_without_effort': int(len(self.df) - len(effort_df))
            }
        }

    def get_category_breakdown(self) -> list:
        req_cols = ['AI_Category', 'AI_Subcategory']
        if self.df.empty or not all(c in self.df.columns for c in req_cols):
             return []

        breakdown = self.df.groupby(req_cols).size().reset_index()
        breakdown.columns = ['category', 'subcategory', 'count']
        breakdown = breakdown.sort_values('count', ascending=False)
        return breakdown.to_dict('records')

    def get_volume_by_month(self) -> list:
        if self.df.empty or 'Created' not in self.df.columns:
            return []
        
        try:
            df = self.df.copy()
            df['YearMonth'] = pd.to_datetime(df['Created'], errors='coerce').dt.to_period('M').astype(str)
            # Remove NaT if any
            df = df[df['YearMonth'] != 'NaT']
            if df.empty:
                return []
                
            monthly = df.groupby('YearMonth').size().reset_index()
            monthly.columns = ['period', 'count']
            return monthly.to_dict('records')
        except Exception as e:
            print(f"Error in get_volume_by_month: {e}")
            return []

    def get_summary(self) -> dict:
        total_tickets = len(self.df)
        if total_tickets == 0:
            return {
                'total_tickets': 0,
                'unique_groups': 0,
                'unique_categories': 0,
                'total_effort_hours': 0,
                'avg_effort_hours': 0,
                'top_group': 'N/A',
            }

        effort_col = 'Effort_Hours' if 'Effort_Hours' in self.df.columns else None
        effort_df = self.df[self.df[effort_col].notna()] if effort_col else pd.DataFrame()
        
        group_col = 'AI_Group' if 'AI_Group' in self.df.columns else None
        category_col = 'AI_Category' if 'AI_Category' in self.df.columns else None
        
        top_group = 'N/A'
        if group_col and not self.df[group_col].empty:
            counts = self.df[group_col].value_counts()
            if not counts.empty:
                top_group = counts.idxmax()

        return {
            'total_tickets': total_tickets,
            'unique_groups': int(self.df[group_col].nunique()) if group_col else 0,
            'unique_categories': int(self.df[category_col].nunique()) if category_col else 0,
            'total_effort_hours': round(float(effort_df['Effort_Hours'].sum()), 2) if not effort_df.empty else 0,
            'avg_effort_hours': round(float(effort_df['Effort_Hours'].mean()), 2) if not effort_df.empty else 0,
            'top_group': top_group,
        }
