import pandas as pd
from effort_extractor import EffortExtractor
from datetime import datetime

def test_effort_extraction():
    extractor = EffortExtractor()
    
    # Test case 1: Diverse formats in one string
    notes = """
    2024-01-15 09:30:00 - Started work
    Jan 15, 2024 10:30:00 - Middle point
    2024-01-15 11:30:00 - Finished
    """
    df = pd.DataFrame({'Work notes': [notes]})
    result = extractor.extract_effort(df)
    
    assert result.iloc[0]['Note_Count'] == 3
    assert result.iloc[0]['Effort_Hours'] == 2.0
    print("Test 1 (Diverse formats) passed.")

    # Test case 2: AM/PM format
    notes_ampm = """
    01/15/2024 09:00:00 AM - Morning
    01/15/2024 02:00:00 PM - Afternoon
    """
    df_ampm = pd.DataFrame({'work_notes': [notes_ampm]}) # Case-insensitive col check
    result_ampm = extractor.extract_effort(df_ampm)
    
    assert result_ampm.iloc[0]['Note_Count'] == 2
    assert result_ampm.iloc[0]['Effort_Hours'] == 5.0
    print("Test 2 (AM/PM and Case-insensitive Column) passed.")

    # Test case 3: Single timestamp
    notes_single = "2024-01-15 09:30:00 - One note only"
    df_single = pd.DataFrame({'Comments': [notes_single]})
    result_single = extractor.extract_effort(df_single)
    
    assert result_single.iloc[0]['Note_Count'] == 1
    assert result_single.iloc[0]['Effort_Hours'] == 0.5
    print("Test 3 (Single Timestamp) passed.")

    # Test case 4: Full Month Name
    notes_full = "15 January 2024 09:00:00 - Start\n15 January 2024 10:00:00 - End"
    df_full = pd.DataFrame({'Comments Work notes': [notes_full]})
    result_full = extractor.extract_effort(df_full)
    
    assert result_full.iloc[0]['Note_Count'] == 2
    assert result_full.iloc[0]['Effort_Hours'] == 1.0
    print("Test 4 (Full Month Name) passed.")

if __name__ == "__main__":
    try:
        test_effort_extraction()
        print("\nAll effort extraction tests passed successfully!")
    except Exception as e:
        print(f"\nTests failed: {e}")
        import traceback
        traceback.print_exc()
