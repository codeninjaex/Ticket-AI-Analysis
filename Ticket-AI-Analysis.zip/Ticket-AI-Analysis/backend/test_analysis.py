import pandas as pd
import numpy as np
from analysis import TicketAnalyzer

def test_analyzer_robustness():
    # Test case 1: Normal valid data
    df_normal = pd.DataFrame({
        'AI_Group': ['A', 'A', 'B'],
        'AI_Category': ['Cat1', 'Cat1', 'Cat2'],
        'AI_Subcategory': ['Sub1', 'Sub1', 'Sub2'],
        'Effort_Hours': [1.0, 2.0, 0.5],
        'Created': ['2024-01-01', '2024-01-02', '2024-02-01']
    })
    analyzer = TicketAnalyzer(df_normal)
    summary = analyzer.get_summary()
    assert summary['total_tickets'] == 3
    assert summary['unique_groups'] == 2
    assert summary['total_effort_hours'] == 3.5
    print("Test 1 (Normal Data) passed.")

    # Test case 2: Empty DataFrame
    df_empty = pd.DataFrame()
    analyzer = TicketAnalyzer(df_empty)
    summary = analyzer.get_summary()
    assert summary['total_tickets'] == 0
    assert summary['top_group'] == 'N/A'
    assert analyzer.get_heavy_hitters()['heavy_hitters'] == []
    assert analyzer.get_effort_summary()['effort_by_group'] == []
    assert analyzer.get_category_breakdown() == []
    assert analyzer.get_volume_by_month() == []
    print("Test 2 (Empty Data) passed.")

    # Test case 3: Missing columns
    df_missing = pd.DataFrame({'Short Description': ['test']})
    analyzer = TicketAnalyzer(df_missing)
    summary = analyzer.get_summary()
    assert summary['total_tickets'] == 1
    assert summary['unique_groups'] == 0
    assert analyzer.get_heavy_hitters()['heavy_hitters'] == []
    assert analyzer.get_category_breakdown() == []
    print("Test 3 (Missing Columns) passed.")

    # Test case 4: All nulls in effort
    df_null_effort = pd.DataFrame({
        'AI_Group': ['A'],
        'Effort_Hours': [np.nan]
    })
    analyzer = TicketAnalyzer(df_null_effort)
    effort = analyzer.get_effort_summary()
    assert effort['overall']['total_hours'] == 0
    assert effort['overall']['tickets_with_effort'] == 0
    print("Test 4 (Null Effort) passed.")

if __name__ == "__main__":
    try:
        test_analyzer_robustness()
        print("\nAll analysis tests passed successfully!")
    except Exception as e:
        print(f"\nTests failed: {e}")
        import traceback
        traceback.print_exc()
