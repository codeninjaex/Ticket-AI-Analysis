from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
import pandas as pd
import os
import werkzeug
from gemini_categorizer import GeminiCategorizer
from effort_extractor import EffortExtractor
from analysis import TicketAnalyzer
from excel_exporter import ExcelExporter

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs('output', exist_ok=True)

# Global state (for demo; use a job queue like Celery in production)
pipeline_results = {
    'df': None,
    'analyzer': None,
    'status': 'idle',
    'message': '',
    'error': None
}

def load_csv_robustly(filepath: str) -> pd.DataFrame:
    """Try various encodings to load the CSV safely"""
    encodings = ['utf-8', 'latin-1', 'utf-8-sig', 'cp1252']
    for enc in encodings:
        try:
            df = pd.read_csv(filepath, encoding=enc)
            if df.empty:
                raise ValueError("The uploaded CSV is empty.")
            return df
        except (UnicodeDecodeError, pd.errors.ParserError):
            continue
    # If all fail, try one last time to raise the original error
    return pd.read_csv(filepath)

def run_pipeline(filepath: str):
    global pipeline_results
    try:
        pipeline_results['status'] = 'running'
        pipeline_results['error'] = None
        pipeline_results['message'] = 'Loading and detecting CSV encoding...'

        df = load_csv_robustly(filepath)
        print(f"Loaded {len(df)} rows with columns: {df.columns.tolist()}")

        pipeline_results['message'] = 'Categorizing with Gemini AI...'
        categorizer = GeminiCategorizer()
        df = categorizer.categorize_tickets(df)

        pipeline_results['message'] = 'Extracting effort from work notes...'
        extractor = EffortExtractor()
        df = extractor.extract_effort(df)

        pipeline_results['message'] = 'Running analysis engine...'
        analyzer = TicketAnalyzer(df)

        pipeline_results['message'] = 'Generating Excel visualization...'
        exporter = ExcelExporter()
        exporter.export(df, analyzer)

        pipeline_results['df'] = df
        pipeline_results['analyzer'] = analyzer
        pipeline_results['status'] = 'complete'
        pipeline_results['message'] = 'Analysis complete'

    except Exception as e:
        pipeline_results['status'] = 'error'
        pipeline_results['message'] = 'Pipeline failed'
        pipeline_results['error'] = str(e)
        print(f"Pipeline error: {e}")
        # We don't re-raise here so the API can still serve the error status

@app.route('/api/upload', methods=['POST'])
def upload_file():
    """Handle multipart file upload and start pipeline"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part in the request'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if file:
        filename = werkzeug.utils.secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
        
        # Reset state and run
        global pipeline_results
        pipeline_results['status'] = 'idle'
        pipeline_results['df'] = None
        pipeline_results['analyzer'] = None
        
        try:
            run_pipeline(filepath)
            if pipeline_results['status'] == 'error':
                 return jsonify({'status': 'error', 'message': pipeline_results['error']}), 500
            return jsonify({'status': 'complete', 'message': 'File uploaded and analyzed successfully'})
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/run', methods=['POST'])
def run_analysis():
    """Fallback for local files"""
    filepath = request.json.get('filepath', 'data/tickets.csv')
    if not os.path.exists(filepath):
        return jsonify({'error': f'File not found: {filepath}'}), 404
    try:
        run_pipeline(filepath)
        if pipeline_results['status'] == 'error':
             return jsonify({'status': 'error', 'message': pipeline_results['error']}), 500
        return jsonify({'status': 'complete', 'message': 'Analysis complete'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    return jsonify({
        'status': pipeline_results['status'],
        'message': pipeline_results['message'],
        'error': pipeline_results['error']
    })

@app.route('/api/summary', methods=['GET'])
def get_summary():
    if not pipeline_results['analyzer']:
        return jsonify({'error': 'No analysis data available. Please upload a file first.'}), 400
    return jsonify(pipeline_results['analyzer'].get_summary())

@app.route('/api/heavy-hitters', methods=['GET'])
def get_heavy_hitters():
    if not pipeline_results['analyzer']:
        return jsonify({'error': 'No data'}), 400
    top_n = request.args.get('top_n', 15, type=int)
    return jsonify(pipeline_results['analyzer'].get_heavy_hitters(top_n))

@app.route('/api/effort', methods=['GET'])
def get_effort():
    if not pipeline_results['analyzer']:
        return jsonify({'error': 'No data'}), 400
    return jsonify(pipeline_results['analyzer'].get_effort_summary())

@app.route('/api/category-breakdown', methods=['GET'])
def get_category_breakdown():
    if not pipeline_results['analyzer']:
        return jsonify({'error': 'No data'}), 400
    return jsonify(pipeline_results['analyzer'].get_category_breakdown())

@app.route('/api/volume-trends', methods=['GET'])
def get_volume_trends():
    if not pipeline_results['analyzer']:
        return jsonify({'error': 'No data'}), 400
    return jsonify(pipeline_results['analyzer'].get_volume_by_month())

@app.route('/api/download-excel', methods=['GET'])
def download_excel():
    path = 'output/ticket_analysis.xlsx'
    if not os.path.exists(path):
        return jsonify({'error': 'Excel report not found. Has the analysis finished?'}), 404
    return send_file(path, as_attachment=True, download_name='ticket_analysis.xlsx')

if __name__ == '__main__':
    app.run(debug=True, port=5000)
