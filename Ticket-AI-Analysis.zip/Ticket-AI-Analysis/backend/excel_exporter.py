import pandas as pd
import numpy as np
import re
from openpyxl import Workbook
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side, GradientFill
)
from openpyxl.chart import BarChart, Reference, LineChart
from openpyxl.chart.series import SeriesLabel
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.formatting.rule import ColorScaleRule, DataBarRule
import os

class ExcelExporter:
    # Color palette
    HEADER_COLOR = "4F46E5"
    SUBHEADER_COLOR = "818CF8"
    ALT_ROW_COLOR = "EEF2FF"
    GREEN = "10B981"
    AMBER = "F59E0B"
    RED = "EF4444"
    WHITE = "FFFFFF"
    LIGHT_GRAY = "F9FAFB"
    BORDER_COLOR = "CCCCCC"

    def _get_border(self):
        side = Side(style='thin', color=self.BORDER_COLOR)
        return Border(left=side, right=side, top=side, bottom=side)

    def _clean_string(self, value):
        """Remove illegal characters that cause Excel save errors"""
        if not isinstance(value, str):
            return value
        # Remove control characters
        return re.sub(r'[\000-\010\013\014\016-\037]', '', value)

    def export(self, df: pd.DataFrame, analyzer, output_path: str = "output/ticket_analysis.xlsx"):
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        wb = Workbook()
        wb.remove(wb.active)  # Remove default sheet

        self._add_summary_sheet(wb, analyzer)
        self._add_heavy_hitters_sheet(wb, analyzer)
        self._add_effort_sheet(wb, analyzer)
        self._add_category_breakdown_sheet(wb, analyzer)
        self._add_raw_data_sheet(wb, df)

        wb.save(output_path)
        print(f"Excel report saved to: {output_path}")
        return output_path

    # ──────────────────────────────────────────────
    # Sheet 1: Executive Summary
    # ──────────────────────────────────────────────
    def _add_summary_sheet(self, wb: Workbook, analyzer):
        ws = wb.create_sheet("📊 Summary")
        ws.sheet_view.showGridLines = False

        summary = analyzer.get_summary()
        effort = analyzer.get_effort_summary()

        # Title
        ws.merge_cells("A1:F1")
        ws["A1"] = "Ticket Analysis — Executive Summary"
        ws["A1"].font = Font(size=18, bold=True, color=self.WHITE)
        ws["A1"].fill = PatternFill("solid", fgColor=self.HEADER_COLOR)
        ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 40

        # KPI Cards (row 3)
        kpis = [
            ("Total Tickets", summary.get('total_tickets', 0)),
            ("Unique Groups", summary.get('unique_groups', 0)),
            ("Unique Categories", summary.get('unique_categories', 0)),
            ("Total Effort (hrs)", summary.get('total_effort_hours', 0)),
            ("Avg Effort/Ticket (hrs)", summary.get('avg_effort_hours', 0)),
            ("Top Group", summary.get('top_group', 'N/A')),
        ]

        col = 1
        for label, value in kpis:
            label_cell = ws.cell(row=3, column=col, value=label)
            value_cell = ws.cell(row=4, column=col, value=value)

            label_cell.fill = PatternFill("solid", fgColor=self.SUBHEADER_COLOR)
            label_cell.font = Font(bold=True, color=self.WHITE, size=10)
            label_cell.alignment = Alignment(horizontal="center")
            label_cell.border = self._get_border()

            value_cell.fill = PatternFill("solid", fgColor=self.ALT_ROW_COLOR)
            value_cell.font = Font(bold=True, size=12, color=self.HEADER_COLOR)
            value_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            value_cell.border = self._get_border()

            ws.column_dimensions[get_column_letter(col)].width = 22
            col += 1

        ws.row_dimensions[3].height = 25
        ws.row_dimensions[4].height = 45

        # Effort overview table
        row = 7
        ws.cell(row=row, column=1, value="Effort Overview (Top 20 Groups)").font = Font(bold=True, size=13, color=self.HEADER_COLOR)
        row += 1

        headers = ["Group", "Ticket Count", "Total Hours", "Avg Hours", "Min Hours", "Max Hours"]
        for col_idx, h in enumerate(headers, 1):
            c = ws.cell(row=row, column=col_idx, value=h)
            c.fill = PatternFill("solid", fgColor=self.HEADER_COLOR)
            c.font = Font(bold=True, color=self.WHITE)
            c.alignment = Alignment(horizontal="center")
            c.border = self._get_border()

        row += 1
        groups_data = effort.get('effort_by_group', [])
        if not groups_data:
            ws.cell(row=row, column=1, value="No effort data available.")
        else:
            for i, item in enumerate(groups_data[:20]):
                fill_color = self.ALT_ROW_COLOR if i % 2 == 0 else self.WHITE
                values = [
                    item.get('AI_Group', 'N/A'), item.get('ticket_count', 0),
                    item.get('total_hours', 0), item.get('avg_hours', 0),
                    item.get('min_hours', 0), item.get('max_hours', 0)
                ]
                for col_idx, val in enumerate(values, 1):
                    c = ws.cell(row=row, column=col_idx, value=self._clean_string(val))
                    c.fill = PatternFill("solid", fgColor=fill_color)
                    c.alignment = Alignment(horizontal="center" if col_idx > 1 else "left")
                    c.border = self._get_border()
                row += 1

        ws.column_dimensions["A"].width = 40

    # ──────────────────────────────────────────────
    # Sheet 2: Heavy Hitters
    # ──────────────────────────────────────────────
    def _add_heavy_hitters_sheet(self, wb: Workbook, analyzer):
        ws = wb.create_sheet("🔥 Heavy Hitters")
        ws.sheet_view.showGridLines = False

        data = analyzer.get_heavy_hitters(15)
        hh = data.get('heavy_hitters', [])

        # Title
        ws.merge_cells("A1:F1")
        coverage = data.get('coverage_pct', 0)
        ws["A1"] = f"Heavy Hitters — Top {len(hh)} Groups ({coverage}% coverage)"
        ws["A1"].font = Font(size=14, bold=True, color=self.WHITE)
        ws["A1"].fill = PatternFill("solid", fgColor=self.HEADER_COLOR)
        ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 32

        headers = ["Rank", "Group", "Ticket Count", "Percentage (%)", "Cumulative (%)"]
        for col_idx, h in enumerate(headers, 1):
            c = ws.cell(row=3, column=col_idx, value=h)
            c.fill = PatternFill("solid", fgColor=self.HEADER_COLOR)
            c.font = Font(bold=True, color=self.WHITE)
            c.alignment = Alignment(horizontal="center")
            c.border = self._get_border()

        if not hh:
            ws.cell(row=4, column=1, value="No group data available.")
        else:
            for i, item in enumerate(hh, 1):
                row = i + 3
                fill_color = self.ALT_ROW_COLOR if i % 2 == 0 else self.WHITE
                vals = [i, item.get('group', 'N/A'), item.get('count', 0), item.get('percentage', 0), item.get('cumulative_percentage', 0)]
                for col_idx, val in enumerate(vals, 1):
                    c = ws.cell(row=row, column=col_idx, value=self._clean_string(val))
                    c.fill = PatternFill("solid", fgColor=fill_color)
                    c.alignment = Alignment(horizontal="center" if col_idx != 2 else "left")
                    c.border = self._get_border()

            # Apply conditional formatting only if we have data
            last_data_row = len(hh) + 3
            ws.conditional_formatting.add(
                f"C4:C{last_data_row}",
                DataBarRule(start_type="min", end_type="max", color=self.HEADER_COLOR)
            )
            ws.conditional_formatting.add(
                f"E4:E{last_data_row}",
                ColorScaleRule(
                    start_type='min', start_color=self.GREEN,
                    mid_type='percentile', mid_value=50, mid_color=self.AMBER,
                    end_type='max', end_color=self.RED
                )
            )

            # Bar chart
            chart = BarChart()
            chart.type = "bar"
            chart.title = "Heavy Hitters by Ticket Volume"
            chart.y_axis.title = "Group"
            chart.x_axis.title = "Count"
            chart.height = 18
            chart.width = 22
            chart.legend = None

            data_ref = Reference(ws, min_col=3, min_row=3, max_row=last_data_row)
            cats_ref = Reference(ws, min_col=2, min_row=4, max_row=last_data_row)
            chart.add_data(data_ref, titles_from_data=True)
            chart.set_categories(cats_ref)
            ws.add_chart(chart, "G3")

        col_widths = [8, 45, 15, 18, 18]
        for col_idx, w in enumerate(col_widths, 1):
            ws.column_dimensions[get_column_letter(col_idx)].width = w

    # ──────────────────────────────────────────────
    # Sheet 3: Effort Analysis
    # ──────────────────────────────────────────────
    def _add_effort_sheet(self, wb: Workbook, analyzer):
        ws = wb.create_sheet("⏱️ Effort Analysis")
        ws.sheet_view.showGridLines = False

        effort = analyzer.get_effort_summary()
        overall = effort.get('overall', {})
        groups = effort.get('effort_by_group', [])

        ws.merge_cells("A1:G1")
        ws["A1"] = "Effort Analysis by Group"
        ws["A1"].font = Font(size=14, bold=True, color=self.WHITE)
        ws["A1"].fill = PatternFill("solid", fgColor=self.GREEN)
        ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 32

        # Overall KPIs
        kpis = [
            ("Total Hours Logged", overall.get('total_hours', 0)),
            ("Avg Hours/Ticket", overall.get('avg_hours_per_ticket', 0)),
            ("Tickets with Effort", overall.get('tickets_with_effort', 0)),
            ("Tickets w/o Data", overall.get('tickets_without_effort', 0)),
        ]
        for col_idx, (label, val) in enumerate(kpis, 1):
            lbl = ws.cell(row=3, column=col_idx, value=label)
            lbl.font = Font(bold=True, color=self.WHITE)
            lbl.fill = PatternFill("solid", fgColor=self.GREEN)
            lbl.alignment = Alignment(horizontal="center")
            lbl.border = self._get_border()

            vcell = ws.cell(row=4, column=col_idx, value=val)
            vcell.font = Font(bold=True, size=13)
            vcell.alignment = Alignment(horizontal="center")
            vcell.border = self._get_border()
            ws.column_dimensions[get_column_letter(col_idx)].width = 22

        ws.row_dimensions[3].height = 24
        ws.row_dimensions[4].height = 30

        # Detail table
        headers = ["Group", "Ticket Count", "Total Hours", "Avg Hours/Ticket", "Min Hours", "Max Hours"]
        for col_idx, h in enumerate(headers, 1):
            c = ws.cell(row=6, column=col_idx, value=h)
            c.fill = PatternFill("solid", fgColor=self.GREEN)
            c.font = Font(bold=True, color=self.WHITE)
            c.alignment = Alignment(horizontal="center")
            c.border = self._get_border()

        if not groups:
            ws.cell(row=7, column=1, value="No effort data available.")
        else:
            for i, item in enumerate(groups, 1):
                row = i + 6
                fill_color = "F0FDF4" if i % 2 == 0 else self.WHITE
                vals = [
                    item.get('AI_Group', 'N/A'), item.get('ticket_count', 0),
                    item.get('total_hours', 0), item.get('avg_hours', 0),
                    item.get('min_hours', 0), item.get('max_hours', 0)
                ]
                for col_idx, val in enumerate(vals, 1):
                    c = ws.cell(row=row, column=col_idx, value=self._clean_string(val))
                    c.fill = PatternFill("solid", fgColor=fill_color)
                    c.alignment = Alignment(horizontal="left" if col_idx == 1 else "center")
                    c.border = self._get_border()

            # Chart
            last_row = len(groups) + 6
            chart = BarChart()
            chart.type = "bar"
            chart.title = "Total Hours by Group"
            chart.height = 16
            chart.width = 20
            chart.legend = None
            data_ref = Reference(ws, min_col=3, min_row=6, max_row=last_row)
            cats_ref = Reference(ws, min_col=1, min_row=7, max_row=last_row)
            chart.add_data(data_ref, titles_from_data=True)
            chart.set_categories(cats_ref)
            ws.add_chart(chart, "H6")

        ws.column_dimensions["A"].width = 40

    # ──────────────────────────────────────────────
    # Sheet 4: Category Breakdown
    # ──────────────────────────────────────────────
    def _add_category_breakdown_sheet(self, wb: Workbook, analyzer):
        ws = wb.create_sheet("📂 Category Breakdown")
        ws.sheet_view.showGridLines = False

        breakdown = analyzer.get_category_breakdown()

        ws.merge_cells("A1:D1")
        ws["A1"] = "Category & Subcategory Breakdown"
        ws["A1"].font = Font(size=14, bold=True, color=self.WHITE)
        ws["A1"].fill = PatternFill("solid", fgColor=self.SUBHEADER_COLOR)
        ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 32

        headers = ["Category", "Subcategory", "Ticket Count", "% of Total"]
        total = sum(r.get('count', 0) for r in breakdown)

        for col_idx, h in enumerate(headers, 1):
            c = ws.cell(row=3, column=col_idx, value=h)
            c.fill = PatternFill("solid", fgColor=self.SUBHEADER_COLOR)
            c.font = Font(bold=True, color=self.WHITE)
            c.alignment = Alignment(horizontal="center")
            c.border = self._get_border()

        if not breakdown:
            ws.cell(row=4, column=1, value="No category data available.")
        else:
            prev_category = None
            for i, item in enumerate(breakdown, 1):
                row = i + 3
                fill_color = self.ALT_ROW_COLOR if i % 2 == 0 else self.WHITE
                cnt = item.get('count', 0)
                pct = round((cnt / total) * 100, 2) if total else 0

                cat_val = item.get('category', 'Uncategorized')
                display_cat = cat_val if cat_val != prev_category else ""
                prev_category = cat_val

                vals = [display_cat, item.get('subcategory', 'N/A'), cnt, pct]
                for col_idx, val in enumerate(vals, 1):
                    c = ws.cell(row=row, column=col_idx, value=self._clean_string(val))
                    c.fill = PatternFill("solid", fgColor=fill_color)
                    c.alignment = Alignment(horizontal="left" if col_idx <= 2 else "center")
                    c.border = self._get_border()

        col_widths = [30, 40, 15, 12]
        for col_idx, w in enumerate(col_widths, 1):
            ws.column_dimensions[get_column_letter(col_idx)].width = w

    # ──────────────────────────────────────────────
    # Sheet 5: Raw Data with enriched columns
    # ──────────────────────────────────────────────
    def _add_raw_data_sheet(self, wb: Workbook, df: pd.DataFrame):
        ws = wb.create_sheet("📋 Raw Data")
        
        # Select and reorder key columns
        keep_cols = [
            'Short Description', 'Category', 'Item',
            'Subcategory 1', 'Subcategory 2',
            'AI_Category', 'AI_Subcategory', 'AI_Group', 'Category_Source',
            'Effort_Hours', 'Note_Count',
            'First_Timestamp', 'Last_Timestamp'
        ]
        existing_cols = [c for c in keep_cols if c in df.columns]
        other_cols = [c for c in df.columns if c not in keep_cols]
        export_df = df[existing_cols + other_cols]

        # Add headers
        for col_idx, col_name in enumerate(export_df.columns, 1):
            c = ws.cell(row=1, column=col_idx, value=col_name)
            c.fill = PatternFill("solid", fgColor=self.HEADER_COLOR)
            c.font = Font(bold=True, color=self.WHITE)
            c.alignment = Alignment(horizontal="center")

        # Add data
        for row_idx, row_data in enumerate(export_df.itertuples(index=False), 2):
            fill_color = self.ALT_ROW_COLOR if row_idx % 2 == 0 else self.WHITE
            for col_idx, val in enumerate(row_data, 1):
                # Check for NaT/NaN
                if pd.isna(val) if not isinstance(val, (str, list, dict)) else False:
                    val = ''
                
                clean_val = self._clean_string(val)
                c = ws.cell(row=row_idx, column=col_idx, value=clean_val)
                c.fill = PatternFill("solid", fgColor=fill_color)
                
                # Basic border for final product feel
                if row_idx <= 500: # Limit border to first 500 rows for performance
                    c.border = Border(
                        left=Side(style='thin', color="EEEEEE"),
                        right=Side(style='thin', color="EEEEEE")
                    )

        # Set widths
        for col_idx in range(1, len(export_df.columns) + 1):
            ws.column_dimensions[get_column_letter(col_idx)].width = 25

        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:{get_column_letter(len(export_df.columns))}1"
