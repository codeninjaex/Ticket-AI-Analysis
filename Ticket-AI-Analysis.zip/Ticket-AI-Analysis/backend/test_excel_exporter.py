import pandas as pd
import os
from excel_exporter import ExcelExporter
from analysis import TicketAnalyzer

def test_excel_export_robustness():
    exporter = ExcelExporter()
    output_path = "output/test_robust_export.xlsx"
    
    # Ensure output dir exists
    os.makedirs("output", exist_ok=True)

    # Test case 1: Data with illegal characters
    df_illegal = pd.DataFrame({
        'Short Description': ['Legal text', 'Illegal char here: \001 and \013', 'Another one: \000'],
        'Category': ['A', 'B', 'C'],
        'AI_Group': ['Group 1', 'Group 2', 'Group 3'],
        'Effort_Hours': [1, 2, 3]
    })
    analyzer = TicketAnalyzer(df_illegal)
    
    try:
        exporter.export(df_illegal, analyzer, output_path)
        print("Test 1 (Illegal Characters) passed - File saved successfully.")
    except Exception as e:
        print(f"Test 1 failed: {e}")
        return

    # Test case 2: Empty Data
    df_empty = pd.DataFrame(columns=['Short Description', 'Category'])
    analyzer_empty = TicketAnalyzer(df_empty)
    output_path_empty = "output/test_empty_export.xlsx"
    
    try:
        exporter.export(df_empty, analyzer_empty, output_path_empty)
        print("Test 2 (Empty Data) passed - File saved successfully.")
    except Exception as e:
        print(f"Test 2 failed: {e}")
        return

if __name__ == "__main__":
    try:
        # We need openpyxl for this
        import openpyxl
        test_excel_export_robustness()
        print("\nAll Excel export tests passed successfully!")
    except ImportError:
        print("openpyxl not installed, skipping tests.")
    except Exception as e:
        print(f"\nTests failed: {e}")
        import traceback
        traceback.print_exc()
