import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import Dashboard from './components/Dashboard';

const API = '[localhost](http://localhost:5000/api)';

export default function App() {
    const [status, setStatus] = useState('idle');
    const [message, setMessage] = useState('');
    const [data, setData] = useState(null);

    const runAnalysis = async () => {
        setStatus('running');
        setMessage('Starting analysis...');
        try {
            const res = await axios.post(`${API}/run`, { filepath: 'data/tickets.csv' });
            setStatus(res.data.status);
            setMessage(res.data.message);
            if (res.data.status === 'complete') fetchDashboardData();
        } catch (err) {
            setStatus('error');
            setMessage(err.response?.data?.message || err.message);
        }
    };

    const fetchDashboardData = useCallback(async () => {
        try {
            const [summary, hh, effort, breakdown, volume] = await Promise.all([
                axios.get(`${API}/summary`),
                axios.get(`${API}/heavy-hitters?top_n=15`),
                axios.get(`${API}/effort`),
                axios.get(`${API}/category-breakdown`),
                axios.get(`${API}/volume-trends`)
            ]);
            setData({
                summary: summary.data,
                heavyHitters: hh.data,
                effort: effort.data,
                breakdown: breakdown.data,
                volume: volume.data
            });
            setStatus('complete');
        } catch (err) {
            console.error('Fetch error:', err);
        }
    }, []);

    useEffect(() => {
        // Try fetching existing data on load
        fetchDashboardData().catch(() => { });
    }, [fetchDashboardData]);

    const downloadExcel = () => {
        window.open(`${API}/download-excel`, '_blank');
    };

    if (status !== 'complete' || !data) {
        return (
            <div className="init-screen">
                <div className="init-card">
                    <h1>🎫 Ticket AI Analyzer</h1>
                    <p>Powered by Gemini AI — categorizes tickets intelligently and calculates resolution effort.</p>

                    {status === 'running' && (
                        <div className="progress-indicator">
                            <div className="spinner"></div>
                            <p>{message}</p>
                        </div>
                    )}

                    {status === 'error' && (
                        <div className="error-box">
                            <p>❌ {message}</p>
                        </div>
                    )}

                    {status !== 'running' && (
                        <button className="run-btn" onClick={runAnalysis}>
                            ▶ Run Analysis
                        </button>
                    )}
                </div>
            </div>
        );
    }

    return <Dashboard data={data} onDownload={downloadExcel} onRefresh={fetchDashboardData} />;
}
