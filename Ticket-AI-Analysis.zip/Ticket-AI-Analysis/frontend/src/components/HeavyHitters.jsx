import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, ReferenceLine } from 'recharts';

const PALETTE = ['#4f46e5', '#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe',
    '#10b981', '#34d399', '#6ee7b7', '#f59e0b', '#fbbf24',
    '#ef4444', '#f87171', '#8b5cf6', '#a78bfa', '#06b6d4'];

const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) return null;
    const d = payload[0].payload;
    return (
        <div className="custom-tooltip">
            <p className="tt-title">{d.group}</p>
            <p>Count: <strong>{d.count.toLocaleString()}</strong></p>
            <p>Share: <strong>{d.percentage}%</strong></p>
            <p>Cumulative: <strong>{d.cumulative_percentage}%</strong></p>
        </div>
    );
};

export default function HeavyHitters({ data }) {
    if (!data) return null;
    const { heavy_hitters, total_tickets, coverage_pct } = data;

    return (
        <div>
            <div className="coverage-pill">
                Top {heavy_hitters.length} groups → <strong>{coverage_pct}%</strong> of {total_tickets.toLocaleString()} tickets
            </div>

            <ResponsiveContainer width="100%" height={360}>
                <BarChart data={heavy_hitters} layout="vertical" margin={{ left: 10, right: 40 }}>
                    <XAxis type="number" tick={{ fontSize: 11 }} />
                    <YAxis
                        type="category"
                        dataKey="group"
                        width={200}
                        tick={{ fontSize: 11 }}
                        tickFormatter={v => v.length > 32 ? v.slice(0, 30) + '…' : v}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                        {heavy_hitters.map((_, i) => (
                            <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                        ))}
                    </Bar>
                </BarChart>
            </ResponsiveContainer>

            <div className="table-wrap">
                <table className="dtable">
                    <thead>
                        <tr>
                            <th>#</th><th>Group</th><th>Count</th><th>%</th><th>Cumulative</th>
                        </tr>
                    </thead>
                    <tbody>
                        {heavy_hitters.map((r, i) => (
                            <tr key={r.group} className={i % 2 === 0 ? 'alt' : ''}>
                                <td className="center">{i + 1}</td>
                                <td>{r.group}</td>
                                <td className="center">{r.count.toLocaleString()}</td>
                                <td className="center">{r.percentage}%</td>
                                <td>
                                    <div className="pbar">
                                        <div className="pfill" style={{ width: `${Math.min(r.cumulative_percentage, 100)}%` }} />
                                        <span>{r.cumulative_percentage}%</span>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
