import React from 'react';
import HeavyHitters from './HeavyHitters';
import EffortAnalysis from './EffortAnalysis';
import CategoryBreakdown from './CategoryBreakdown';
import VolumeChart from './VolumeChart';

export default function Dashboard({ data, onDownload, onRefresh }) {
    const { summary, heavyHitters, effort, breakdown, volume } = data;

    return (
        <div className="dashboard">
            <header className="dash-header">
                <div className="header-left">
                    <h1>🎫 Ticket AI Analysis Dashboard</h1>
                    <span className="ai-badge">Powered by Gemini AI</span>
                </div>
                <div className="header-actions">
                    <button className="btn-secondary" onClick={onRefresh}>↻ Refresh</button>
                    <button className="btn-primary" onClick={onDownload}>⬇ Download Excel</button>
                </div>
            </header>

            {/* KPI Strip */}
            <div className="kpi-strip">
                {[
                    { label: 'Total Tickets', value: summary.total_tickets?.toLocaleString(), color: '#4f46e5' },
                    { label: 'Unique Groups', value: summary.unique_groups, color: '#6366f1' },
                    { label: 'Categories', value: summary.unique_categories, color: '#8b5cf6' },
                    { label: 'Total Effort (hrs)', value: summary.total_effort_hours?.toLocaleString(), color: '#10b981' },
                    { label: 'Avg hrs/Ticket', value: summary.avg_effort_hours, color: '#f59e0b' },
                    { label: 'Top Group', value: summary.top_group, color: '#ef4444', wide: true }
                ].map(kpi => (
                    <div key={kpi.label} className={`kpi-card ${kpi.wide ? 'kpi-wide' : ''}`}>
                        <span className="kpi-value" style={{ color: kpi.color }}>{kpi.value}</span>
                        <span className="kpi-label">{kpi.label}</span>
                    </div>
                ))}
            </div>

            {/* Main Grid */}
            <div className="dash-grid">
                <section className="card span-2">
                    <h2>🔥 Heavy Hitters</h2>
                    <HeavyHitters data={heavyHitters} />
                </section>

                <section className="card">
                    <h2>⏱️ Effort by Group</h2>
                    <EffortAnalysis data={effort} />
                </section>

                <section className="card">
                    <h2>📂 Category Breakdown</h2>
                    <CategoryBreakdown data={breakdown} />
                </section>

                <section className="card span-2">
                    <h2>📈 Volume Trend</h2>
                    <VolumeChart data={volume} />
                </section>
            </div>
        </div>
    );
}
