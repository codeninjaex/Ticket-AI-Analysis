import React from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function VolumeChart({ data }) {
    if (!data || data.length === 0) return <p>No trend data (requires Created date column)</p>;

    return (
        <ResponsiveContainer width="100%" height={260}>
            <LineChart data={data} margin={{ bottom: 40, right: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis
                    dataKey="period"
                    tick={{ fontSize: 11 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                    interval="preserveStartEnd"
                />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => [`${v} tickets`, 'Volume']} />
                <Line
                    type="monotone"
                    dataKey="count"
                    stroke="#4f46e5"
                    strokeWidth={2.5}
                    dot={{ r: 4, fill: '#4f46e5' }}
                    activeDot={{ r: 6 }}
                    name="Ticket Volume"
                />
            </LineChart>
        </ResponsiveContainer>
    );
}
