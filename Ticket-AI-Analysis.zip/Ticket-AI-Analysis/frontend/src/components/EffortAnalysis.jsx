import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function EffortAnalysis({ data }) {
    if (!data) return null;
    const { effort_by_group, overall } = data;

    return (
        <div>
            <div className="effort-kpis">
                <div className="ekpi">
                    <span style={{ color: '#10b981' }}>{overall.total_hours?.toLocaleString()}</span>
                    <span>Total Hours</span>
                </div>
                <div className="ekpi">
                    <span style={{ color: '#10b981' }}>{overall.avg_hours_per_ticket}</span>
                    <span>Avg hrs/Ticket</span>
                </div>
                <div className="ekpi">
                    <span style={{ color: '#f59e0b' }}>{overall.tickets_with_effort?.toLocaleString()}</span>
                    <span>With Data</span>
                </div>
                <div className="ekpi">
                    <span style={{ color: '#ef4444' }}>{overall.tickets_without_effort?.toLocaleString()}</span>
                    <span>No Data</span>
                </div>
            </div>

            <ResponsiveContainer width="100%" height={280}>
                <BarChart
                    data={effort_by_group.slice(0, 10)}
                    layout="vertical"
                    margin={{ left: 10, right: 30 }}
                >
                    <XAxis type="number" tick={{ fontSize: 11 }} />
                    <YAxis
                        type="category"
                        dataKey="AI_Group"
                        width={190}
                        tick={{ fontSize: 10 }}
                        tickFormatter={v => v.length > 30 ? v.slice(0, 28) + '…' : v}
                    />
                    <Tooltip
                        formatter={(v, n) => [
                            n === 'total_hours' ? `${v} hrs` : v,
                            n === 'total_hours' ? 'Total Hours' : n
                        ]}
                    />
                    <Bar dataKey="total_hours" fill="#10b981" radius={[0, 4, 4, 0]} />
                </BarChart>
            </ResponsiveContainer>

            <div className="table-wrap" style={{ marginTop: 12 }}>
                <table className="dtable">
                    <thead>
                        <tr>
                            <th>Group</th><th>Tickets</th><th>Total hrs</th><th>Avg hrs</th>
                        </tr>
                    </thead>
                    <tbody>
                        {effort_by_group.slice(0, 12).map((r, i) => (
                            <tr key={r.AI_Group} className={i % 2 === 0 ? 'alt' : ''}>
                                <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                                    title={r.AI_Group}>{r.AI_Group}</td>
                                <td className="center">{r.ticket_count}</td>
                                <td className="center">{r.total_hours}</td>
                                <td className="center">{r.avg_hours}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
