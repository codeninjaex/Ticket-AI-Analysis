import React, { useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16'];

export default function CategoryBreakdown({ data }) {
    const [view, setView] = useState('chart');

    if (!data || data.length === 0) return <p>No data</p>;

    // Aggregate by top-level category for pie
    const categoryMap = {};
    data.forEach(r => {
        if (!categoryMap[r.category]) categoryMap[r.category] = 0;
        categoryMap[r.category] += r.count;
    });
    const pieData = Object.entries(categoryMap)
        .map(([name, value]) => ({ name, value }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 8);

    const total = pieData.reduce((s, r) => s + r.value, 0);

    return (
        <div>
            <div className="toggle-group">
                <button className={view === 'chart' ? 'active' : ''} onClick={() => setView('chart')}>Chart</button>
                <button className={view === 'table' ? 'active' : ''} onClick={() => setView('table')}>Table</button>
            </div>

            {view === 'chart' ? (
                <ResponsiveContainer width="100%" height={320}>
                    <PieChart>
                        <Pie
                            data={pieData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={110}
                            label={({ name, percent }) => `${name} ${(percent * 100).toFixed(1)}%`}
                            labelLine={true}
                        >
                            {pieData.map((_, i) => (
                                <Cell key={i} fill={COLORS[i % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip formatter={(v) => [`${v} tickets`, 'Count']} />
                    </PieChart>
                </ResponsiveContainer>
            ) : (
                <div className="table-wrap">
                    <table className="dtable">
                        <thead>
                            <tr><th>Category</th><th>Subcategory</th><th>Count</th><th>%</th></tr>
                        </thead>
                        <tbody>
                            {data.slice(0, 25).map((r, i) => (
                                <tr key={i} className={i % 2 === 0 ? 'alt' : ''}>
                                    <td>{r.category}</td>
                                    <td>{r.subcategory}</td>
                                    <td className="center">{r.count}</td>
                                    <td className="center">{((r.count / total) * 100).toFixed(1)}%</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );
}
